import re
import numpy as np

## CODE FOR EXTRACTING MATRICES
"""matrices = {}
current_id = None

with open("pdb3j6s.ent") as f:
    for line in f:
        if line.startswith("REMARK 350   BIOMT"):
            parts = line.split()

            row_type = parts[2]   # BIOMT1, BIOMT2, BIOMT3
            mat_id = parts[3]     # matrix number (e.g. "1")

            values = list(map(float, parts[4:7]))  # 3 matrix values

            if mat_id not in matrices:
                matrices[mat_id] = []

            matrices[mat_id].append(values)

# Write matrices to output file
with open("matrices.txt", "w") as out:
    for mid, mat in matrices.items():
        out.write(f"Matrix {mid}:\n")
        for row in mat:
            out.write(" ".join(f"{v:.6f}" for v in row) + "\n")
        out.write("\n")"""

## CODE FOR EXTRACTING ATOMS - COMMENTED OUT FOR CONVENIENCE

"""chains = {"A": [], "C": [], "E": []}

with open("pdb3j6s.ent") as f:
    for line in f:
        if line.startswith("ATOM"):
            parts = line.split()
            # parts example:
            # ['ATOM','55','CA','THR','A','55','-141.312','-101.073','-136.163','1.00','0.00','C']

            chain_id = parts[4]

            if chain_id in chains:
                x = float(parts[6])
                y = float(parts[7])
                z = float(parts[8])
                chains[chain_id].append([x, y, z])

# Save each chain to its own file
for chain_id, coords in chains.items():
    matrix = np.array(coords)
    filename = f"atoms_chain{chain_id}.txt"

    np.savetxt(filename, matrix, fmt="%.3f")
    print(f"Saved {filename} with shape {matrix.shape}")"""